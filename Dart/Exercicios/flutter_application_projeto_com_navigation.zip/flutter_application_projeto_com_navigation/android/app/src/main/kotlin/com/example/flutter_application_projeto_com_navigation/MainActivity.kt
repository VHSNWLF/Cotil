package com.example.flutter_application_projeto_com_navigation

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
