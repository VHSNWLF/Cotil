class Objetos{
  String nome = "";
  String desc = "";
  String dono = "";
}